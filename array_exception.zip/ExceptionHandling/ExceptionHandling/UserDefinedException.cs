﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExceptionHandling
{
    class CheckAgeException:Exception
    {
        public CheckAgeException(String msg):base(msg)
        {

        }
    }

    class UserDefinedException
    {
        static void checkAge(int age)
        {
            if(age < 18)
            {
                throw new CheckAgeException("You cannot register...");
            }
        }

        public static void Main()
        {
            try
            {
                checkAge(14);
            }
            catch(CheckAgeException e)
            {
                Console.WriteLine(e);
            }
        }
    }
}
