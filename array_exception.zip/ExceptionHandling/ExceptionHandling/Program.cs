﻿using System;

namespace ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 4, 5, 2, 0, 7, 8, 12 };
            for(int i = 0; i < arr.Length; i++)
            {
                try
                {
                    float x = 60 / arr[i];
                    Console.WriteLine(x);
                }
                catch(DivideByZeroException e)
                {
                    Console.WriteLine("Cannot Divide By Zero...");
                }
                catch (IndexOutOfRangeException e)
                {
                    Console.WriteLine("Array Index Out of Range");
                }
            }

            try
            {
                Console.WriteLine(arr[4]);
            }
            catch(IndexOutOfRangeException e)
            {
                Console.WriteLine("Array Index Out of Range");
            }
            finally
            {
                Console.WriteLine("I will always execute...");
            }
        }
    }
}
