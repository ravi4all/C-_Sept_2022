﻿using System;

namespace ArrayCodes
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[] arr = { 4, 3, 6, 8, 1, 3, 12 };
            //int[] arr = new int[5] { 4, 3, 6, 1, 7 };
            int n = 6;
            int[] arr = new int[n];
            string[] arr_1 = { "hello", "world" };
            Console.WriteLine(arr[0]);
            /*for(int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }*/
            foreach(int i in arr)
            {
                Console.WriteLine(i);
            }

            int[,] arr_2 = new int[,]
            {
                {1,2,3 },
                {4,5,6 },
                {7,8,9 }
            };

            int[,] arr_3 = new int[4,4]
            {
                {1,2,3,5 },
                {4,5,6,9 },
                {7,8,9,2 },
                {4,3,7,2 }
            };
        }
    }
}
